// $(function () {
//   var IPName = "http://newb.ishaibiao.com";
//   var wwwpName = "http://www.ishaibiao.com";
//   window.localStorage.setItem("IPName", "http://newb.ishaibiao.com");

//   //====充值提现明细js
//   myToken = window.localStorage.getItem('token');
//   token = window.localStorage.getItem('token');
//   // 获取基本信息

//   //===账户详细信息获取:token
//   var myToken = window.localStorage.getItem('token');
//   var token_status = window.localStorage.getItem('status');
//   var token_approve = window.localStorage.getItem('approve');
//   var token_pai_name = window.localStorage.getItem('name');
//   var token_image_url = window.localStorage.getItem('image');
//   var token_username = window.localStorage.getItem('username');


//   // 依赖
//   // token的基本信息存储到input里面,使用和input元素一起
//   // 获取基本信息
//   $.ajax({
//     type: "POST",
//     url: 'http://newb.ishaibiao.com/api/index/person',
//     async: false,
//     data: {
//       'token': token
//     },
//     dataType: 'json',
//     success: function (info) {
//       // console.log(info, "infoinfoinfoinfo");
//       if (info.code == 1) {
//         // console.log("info.code == 1");
//         // 正常登陆
//         $('#infoStatus').val(info.data.status);
//         $('#infoName').val(info.data.name);
//         $('#infoApprove').val(info.data.approve);
//         $('#infoImage').val(info.data.image);
//         $('#infoUsername').val(info.data.username);
//         $('#teamID').val(info.data.id);
//         $('#enterflag').val(1);
//       } else if (info.code == 8) {
//         // console.log("info.code == 8");
//         // 身份过期
//         $('#infoStatus').val('');
//         $('#infoName').val('');
//         $('#infoApprove').val('');
//         $('#infoImage').val('');
//         $('#infoUsername').val('');
//         $('#enterflag').val(8);
//         $('#teamID').val('');
//         // layer.msg('您的账户已过期,请重新登录后再操作~');
//       } else if (info.code == 0) {
//         // console.log("info.code == 0");
//         // 异常操作: 例如身份不符合
//         $('#infoStatus').val('');
//         $('#infoName').val('');
//         $('#infoApprove').val('');
//         $('#infoImage').val('');
//         $('#infoUsername').val('');
//         $('#enterflag').val(0);
//         $('#teamID').val('');
//         layer.msg(info.msg);
//       }
//     }
//   })

// })

// 获取你想要的时间格式参数(毫秒值，int): 年月日时分秒
// int取值为:0:年1:月2:日3:时4:分5:秒

function getStartTime(startSeconds) {
  var a = getTime(startSeconds, 0) + '';
  var b = getTime(startSeconds, 1) + '';
  var c = getTime(startSeconds, 2) + '';
  var d = getTime(startSeconds, 3) + '';
  var e = getTime(startSeconds, 4) + '';
  var f = getTime(startSeconds, 5) + '';

  var StartTime = a + '-' + b + '-' + c + ' ' + d + ':' + e + ':' + f;
  // <!-- 时间年月日 -->
  function getTime(second, getDateType) {
    var date = new Date(second);
    if (getDateType == 0) {
      return date.getFullYear();
    } else if (getDateType == 1) {
      if (date.getMonth() + 1 <= 9) {
        return '0' + (date.getMonth() + 1);
      } else {
        return date.getMonth() + 1;
      }
    } else if (getDateType == 2) {
      if (date.getDate() <= 9) {
        return '0' + date.getDate();
      } else {
        return date.getDate()
      }
    } else if (getDateType == 3) {
      if (date.getHours() <= 9) {
        return '0' + date.getHours()
      } else {
        return date.getHours();
      }
    } else if (getDateType == 4) {
      if (date.getMinutes() <= 9) {
        return '0' + date.getMinutes();
      } else {
        return date.getMinutes();
      }
    } else if (getDateType == 5) {
      return date.getSeconds();
    } else {
      alert('输入时间格式有误!');
      return
    }
  }
  return StartTime
}
// 获取时间年月日
function getTime(second, getDateType) {
  var date = new Date(second);
  if (getDateType == 0) {
    return date.getFullYear();
  } else if (getDateType == 1) {
    if (date.getMonth() + 1 <= 9) {
      return '0' + (date.getMonth() + 1);
    } else {
      return date.getMonth() + 1;
    }
  } else if (getDateType == 2) {
    if (date.getDate() <= 9) {
      return '0' + date.getDate();
    } else {
      return date.getDate()
    }
  } else if (getDateType == 3) {
    if (date.getHours() <= 9) {
      return '0' + date.getHours()
    } else {
      return date.getHours();
    }
  } else if (getDateType == 4) {
    if (date.getMinutes() <= 9) {
      return '0' + date.getMinutes();
    } else {
      return date.getMinutes();
    }
  } else if (getDateType == 5) {
    return date.getSeconds();
  } else {
    alert('输入时间格式有误!');
    return
  }
}


//  对象排序
var sortObj = function (prop, flag) {
  if (flag == undefined) {
    flag = 1;
  } else {
    flag = (flag) ? 1 : -1;
  }

  return function (a, b) {
    a = a[prop];
    b = b[prop];
    if (a == b) {
      return 0;
    } else {
      return a > b ? flag * 1 : flag * -1;
    }
  }
}



// 数组去重
function quChong(array) {
  var quArray = [];
  var len = array.length;
  for (var i = 0; i < len; i++) {
    for (var j = i + 1; j < len; j++) {
      if (array[i][0] === array[j][0]) {
        i++;
        j = i;
      }
    }
    quArray.push(array[i]);
  }
  return quArray;
}

// 筛选标书其他方法
// 得到object的长度 与 value
function getIndexOfArr(arrays, obj) {
  var i = arrays.length;
  while (i--) {
    if (arrays[i] === obj) {
      return i;
    }
  }
  return false;
}

function getObjKeys(obj) {
  var arr = Object.keys(obj);
  return arr;
}

function getObjLength(obj) {
  var arr = Object.keys(obj);
  return arr.length;
}

//
function getJsonValue(obj) {
  var keyArray = [];
  var valueArray = [];
  for (key in obj) {
    keyArray.push(key);
    valueArray.push(obj[key]);
  }
  return valueArray;
}

// 时间戳转换
function time(time = +new Date()) {
  var date = new Date(time + 8 * 3600 * 1000);
  return date.toJSON().substr(0, 19).replace('T', ' ').replace(/-/g, '.');
}


// 展示登录界面判断方法

function showLogin(params) {
  if (getCookie('carbutoken') == '') {
    $('#loginTips_PC').show();
    return;
  }
}

$(document).on('click', '.impTipsFa .close', function name(params) {
  window.localStorage.setItem("impTipsFa", 1);

})
$(document).on('click', '.impTipsFa ', function name(params) {
  window.localStorage.setItem("impTipsFa", 1);

})


$(document).on('click', '.impTipsFa ', function name(params) {
  window.localStorage.setItem("impTipsFa", 1);

})


//demo1 url拼接的参数对象------------------------
// 将一个对象拼接在url的后面:   createURL(url, linkObj)
function createURL(url, param) {
  var urlLink = '';
  $.each(param, function (item, key) {
    var link = '&' + item + "=" + key;
    urlLink += link;
  })
  urlLink = url + "?" + urlLink.substr(1);
  return urlLink.replace(' ', '');
}


//demo2 url拼接的参数对象------------------------
// 解析url 拿到所有参数对象 parseQueryString(urlStr);
function parseQueryString(url) {
  var result = {};
  if (url.indexOf('?') > -1) {
    var str = url.split('?')[1];
    var temp = str.split('&');
    for (var i = 0; i < temp.length; i++) {
      var temp2 = temp[i].split('=');
      result[temp2[0]] = temp2[1];
    }
  }
  return result;
}


///demo3 从地址栏拿到指定参数------------------------
// GetQueryString("uid")
function GetQueryString(name) {
  var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
  var r = window.location.search.substr(1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
}