var tools = {
  getSearchObj: function () {
    var search = location.search
    search = decodeURI(search)
    search = search.slice(1)
    var arr = search.split('&')
    var obj = {}
    //遍历数组
    arr.forEach(function (v) {
      var key = v.split('=')[0]
      var value = v.split('=')[1]
      obj[key] = value
    })
    return obj
  },
  getSearch: function (key) {
    return this.getSearchObj()[key]
  }
}

// 关闭重要提示
$('.impTipsFa').click(function name(params) {
  $(this).hide()
})

// 排序对象数组
function sortObjectArray(objArr, keyArr, type) {
  for (var x = 0; x < objArr.length; x++) {
    objArr[x].oldIndex = x
  }
  if (type != undefined && type != 'asc' && type != 'desc') {
    return 'error'
  }
  var order = 1
  if (type != undefined && type == 'desc') {
    order = -1
  }
  var key = keyArr[0]
  objArr.sort(function (objA, objB) {
    if (objA[key] > objB[key]) {
      return order
    } else if (objA[key] < objB[key]) {
      return 0 - order
    } else {
      if (objA.oldIndex > objB.oldIndex) {
        return order
      } else if (objA.oldIndex < objB.oldIndex) {
        return 0 - order
      } else {
        return 0
      }
    }
  })

  for (var i = 1; i < keyArr.length; i++) {
    var key = keyArr[i]
    for (var y = 0; y < objArr.length; y++) {
      objArr[y].oldIndex = y
    }
    objArr.sort(function (objA, objB) {
      for (var j = 0; j < i; j++) {
        if (objA[keyArr[j]] != objB[keyArr[j]]) {
          if (objA.oldIndex > objB.oldIndex) {
            return order
          } else if (objA.oldIndex < objB.oldIndex) {
            return 0 - order
          } else {
            return 0
          }
        }
      }
      if (objA[key] > objB[key]) {
        return order
      } else if (objA[key] < objB[key]) {
        return 0 - order
      } else {
        if (objA.oldIndex > objB.oldIndex) {
          return order
        } else if (objA.oldIndex < objB.oldIndex) {
          return 0 - order
        } else {
          return 0
        }
      }
    })
  }
  return objArr
}

// 获取你想要的时间格式参数(毫秒值，int): 年月日时分秒
// int取值为:0:年1:月2:日3:时4:分5:秒

function getStartTime(startSeconds) {
  var a = getTime(startSeconds, 0) + ''
  var b = getTime(startSeconds, 1) + ''
  var c = getTime(startSeconds, 2) + ''
  var d = getTime(startSeconds, 3) + ''
  var e = getTime(startSeconds, 4) + ''
  var f = getTime(startSeconds, 5) + ''

  var StartTime = a + '-' + b + '-' + c + ' ' + d + ':' + e + ':' + f
  // <!-- 时间年月日 -->
  function getTime(second, getDateType) {
    var date = new Date(second)
    if (getDateType == 0) {
      return date.getFullYear()
    } else if (getDateType == 1) {
      if (date.getMonth() + 1 <= 9) {
        return '0' + (date.getMonth() + 1)
      } else {
        return date.getMonth() + 1
      }
    } else if (getDateType == 2) {
      if (date.getDate() <= 9) {
        return '0' + date.getDate()
      } else {
        return date.getDate()
      }
    } else if (getDateType == 3) {
      if (date.getHours() <= 9) {
        return '0' + date.getHours()
      } else {
        return date.getHours()
      }
    } else if (getDateType == 4) {
      if (date.getMinutes() <= 9) {
        return '0' + date.getMinutes()
      } else {
        return date.getMinutes()
      }
    } else if (getDateType == 5) {
      return date.getSeconds()
    } else {
      alert('输入时间格式有误!')
      return
    }
  }
  return StartTime
}
// 获取时间年月日
function getTime(second, getDateType) {
  var date = new Date(second)
  if (getDateType == 0) {
    return date.getFullYear()
  } else if (getDateType == 1) {
    if (date.getMonth() + 1 <= 9) {
      return '0' + (date.getMonth() + 1)
    } else {
      return date.getMonth() + 1
    }
  } else if (getDateType == 2) {
    if (date.getDate() <= 9) {
      return '0' + date.getDate()
    } else {
      return date.getDate()
    }
  } else if (getDateType == 3) {
    if (date.getHours() <= 9) {
      return '0' + date.getHours()
    } else {
      return date.getHours()
    }
  } else if (getDateType == 4) {
    if (date.getMinutes() <= 9) {
      return '0' + date.getMinutes()
    } else {
      return date.getMinutes()
    }
  } else if (getDateType == 5) {
    return date.getSeconds()
  } else {
    alert('输入时间格式有误!')
    return
  }
}

//  对象排序
var sortObj = function (prop, flag) {
  if (flag == undefined) {
    flag = 1
  } else {
    flag = flag ? 1 : -1
  }

  return function (a, b) {
    a = a[prop]
    b = b[prop]
    if (a == b) {
      return 0
    } else {
      return a > b ? flag * 1 : flag * -1
    }
  }
}

// 数组去重
function quChong(array) {
  var quArray = []
  var len = array.length
  for (var i = 0; i < len; i++) {
    for (var j = i + 1; j < len; j++) {
      if (array[i][0] === array[j][0]) {
        i++
        j = i
      }
    }
    quArray.push(array[i])
  }
  return quArray
}

// 筛选标书其他方法
// 得到object的长度 与 value
function getIndexOfArr(arrays, obj) {
  var i = arrays.length
  while (i--) {
    if (arrays[i] === obj) {
      return i
    }
  }
  return false
}

function getObjKeys(obj) {
  var arr = Object.keys(obj)
  return arr
}

function getObjLength(obj) {
  var arr = Object.keys(obj)
  return arr.length
}

//
function getJsonValue(obj) {
  var keyArray = []
  var valueArray = []
  for (key in obj) {
    keyArray.push(key)
    valueArray.push(obj[key])
  }
  return valueArray
}

// 对比传递的参数，然后赋值给总参数{aaaa:bbb}
function mostGetChuan(chuanArray) {
  // 修改的参数
  var chuanKey = getObjKeys(chuanArray)
  // 身材
  var chuanKey = getObjKeys(mostSelectArr)
}

// 获得车辆筛选信息
function getStorage() {
  // var object = JSON.parse(window.localStorage.getItem('nowCarId'));
  return ''
}

// 设置筛选信息
function setStorage() {
  // window.localStorage.setItem('mostSelectArr', JSON.stringify(nowCarId));
}

function setCookie(c_name, value, expiredays) {
  var exdate = new Date()
  exdate.setDate(exdate.getDate() + expiredays)
  document.cookie = c_name + '=' + escape(value) + (expiredays == null ? '' : ';expires=' + exdate.toGMTString())
}

function getCookie(c_name) {
  if (document.cookie.length > 0) {
    c_start = document.cookie.indexOf(c_name + '=')
    if (c_start != -1) {
      c_start = c_start + c_name.length + 1
      c_end = document.cookie.indexOf(';', c_start)
      if (c_end == -1) c_end = document.cookie.length
      return unescape(document.cookie.substring(c_start, c_end))
    }
  }
  return ''
}

// 公共变量域名
var IPName = ' http://kabu.dynast.cn'

$(document).on('click', '.impTipsFa .close', function name(params) {
  window.localStorage.setItem("impTipsFa", 1);

})

$(document).on('click', '.impTipsFa ', function name(params) {
  window.localStorage.setItem("impTipsFa", 1);

})
// 所有城市数据

var cityAllArr = [{
  "brandImg": " http://kabu.dynast.cn/uploads/20190704/397d3c61145567a23cb9edcb6baa0017.png",
  "brandName": "悉尼",
  "brand_id": 37,
  "indexCode": "Sydney"
}];



//demo1 url拼接的参数对象------------------------
// 将一个对象拼接在url的后面:   createURL(url, linkObj)
function createURL(url, param) {
  var urlLink = '';
  $.each(param, function (item, key) {
    var link = '&' + item + "=" + key;
    urlLink += link;
  })
  urlLink = url + "?" + urlLink.substr(1);
  return urlLink.replace(' ', '');
}


//demo2 url拼接的参数对象------------------------
// 解析url 拿到所有参数对象 parseQueryString(urlStr);
function parseQueryString(url) {
  var result = {};
  if (url.indexOf('?') > -1) {
    var str = url.split('?')[1];
    var temp = str.split('&');
    for (var i = 0; i < temp.length; i++) {
      var temp2 = temp[i].split('=');
      result[temp2[0]] = temp2[1];
    }
  }
  return result;
}


///demo3 从地址栏拿到指定参数------------------------
// GetQueryString("uid")
function GetQueryString(name) {
  var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
  var r = window.location.search.substr(1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
}