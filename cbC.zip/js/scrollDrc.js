//监听页面滚动事件
;
(function () {
  //滚判时的方法
  function scrollEvent() {
    window.onscroll = function (e) {
      scrollFunc()
      if (scrollDirection == 'down' || scrollDirection == 'up') {
        //页面向下滚动要做的事情
        // $('.fixed_h5img').addClass("scroll_h5img");
        // console.log('页面上下滚动')
      }
    }
  }

  //滚动方向方法
  var scrollAction = {
      x: 'undefined',
      y: 'undefined'
    },
    scrollDirection

  $('.zheOut').click(function name(params) {})
  // 计算滚动方向
  function scrollFunc() {
    if (typeof scrollAction.x == 'undefined') {
      scrollAction.x = $('.zheOut').offset().left
      scrollAction.y = $('.zheOut').offset().top
    }
    var diffX = scrollAction.x - $('.zheOut').offset().left
    var diffY = scrollAction.y - $('.zheOut').offset().top
    if (diffX < 0) {
      // Scroll right
      scrollDirection = 'right'
    } else if (diffX > 0) {
      // Scroll left
      scrollDirection = 'left'
    } else if (diffY < 0) {
      // Scroll down
      scrollDirection = 'down'
    } else if (diffY > 0) {
      // Scroll up
      scrollDirection = 'up'
    } else if ((diffY = 0)) {
      scrollDirection = 'stay'
    }
    scrollAction.x = $('.zheOut').offset().left
    scrollAction.y = $('.zheOut').offset().top
  }

  scrollEvent()
  //定时判断静止

  $('.kb_main').scroll(function name(params) {
    // 时刻监听是否移动
    scrollFunc()
    // 数据
    var zheOutTop = $('.zheOut').offset().top
    var filterHeadHeight = $('.kb_header').height() + $('.kb_filter').height()
    // var scrollHeaderCssDown = {
    // 	position: 'fixed',
    // 	top: '7px',
    // 	'z-index': '20',
    // 	width: '700%',
    // 	background: '#666',
    // 	'box-shadow': ' 0 0rem 0.3rem 0.1rem #000'
    // }
    // var scrollHeaderCssUp = {
    // 	position: 'fixed',
    // 	top: '-700%',
    // 	'z-index': '20',
    // 	width: '700%',
    // 	background: '#666',
    // 	'box-shadow': ' 0 0rem 0.3rem 0.1rem #000'
    // }
    var zheOutMoref700 = {
      'margin-Top': 0
    }

    var zheOutLowf700 = {
      'margin-Top': filterHeadHeight
    }
    // console.log(zheOutTop, 'zheOutTop')

    // 下滑不到足够距离-700
    if (zheOutTop > -700) {
      $('.zheOut').css(zheOutMoref700)
      $('.filterHeaderOut').removeClass('scrollHeaderCssDown')
      $('.filterHeaderOut').removeClass('scrollHeaderCssUp')
    }

    // 下滑到足够距离-700
    if (zheOutTop <= -700) {
      $('.zheOut').css(zheOutLowf700)

      if (scrollDirection == 'down') {
        $('.filterHeaderOut')
          .addClass('scrollHeaderCssDown')
          .removeClass('scrollHeaderCssUp')
      } else if (scrollDirection == 'up') {
        $('.filterHeaderOut')
          .addClass('scrollHeaderCssUp')
          .removeClass('scrollHeaderCssDown')
      }
    }
  })
})()