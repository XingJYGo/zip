function sortObjectArray(objArr, keyArr, type) {
  for (var x = 0; x < objArr.length; x++) {
    objArr[x].oldIndex = x;
  }
  if (type != undefined && type != 'asc' && type != 'desc') {
    return 'error';
  }
  var order = 1;
  if (type != undefined && type == 'desc') {
    order = -1;
  }
  var key = keyArr[0];
  objArr.sort(function (objA, objB) {
    if (objA[key] > objB[key]) {
      return order;
    } else if (objA[key] < objB[key]) {
      return 0 - order;
    } else {
      if (objA.oldIndex > objB.oldIndex) {
        return order;
      } else if (objA.oldIndex < objB.oldIndex) {
        return 0 - order;
      } else {

        return 0;
      }
    }
  })

  for (var i = 1; i < keyArr.length; i++) {
    var key = keyArr[i];
    for (var y = 0; y < objArr.length; y++) {
      objArr[y].oldIndex = y;
    }
    objArr.sort(function (objA, objB) {
      for (var j = 0; j < i; j++) {
        if (objA[keyArr[j]] != objB[keyArr[j]]) {
          if (objA.oldIndex > objB.oldIndex) {
            return order;
          } else if (objA.oldIndex < objB.oldIndex) {
            return 0 - order;
          } else {
            return 0;
          }
        }
      }
      if (objA[key] > objB[key]) {
        return order;
      } else if (objA[key] < objB[key]) {
        return 0 - order;
      } else {
        if (objA.oldIndex > objB.oldIndex) {
          return order;
        } else if (objA.oldIndex < objB.oldIndex) {
          return 0 - order;
        } else {
          return 0;
        }
      }
    })
  }
  return objArr;
}