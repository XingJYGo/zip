// 以来jq
// token的基本信息存储到input里面,使用和input元素一起
function getBaseInfo(token) {
  // console.log("info.code");
  $.ajax({
    type: "POST",
    url: 'http://newb.ishaibiao.com/api/index/person',
    async: false,
    data: {
      'token': token
    },
    dataType: 'json',
    success: function (info) {

      if (info.code == 1) {
        // console.log("info.code == 1");
        // 正常登陆
        $('#infoStatus').val(info.data.status);
        $('#infoName').val(info.data.name);
        $('#infoApprove').val(info.data.approve);
        $('#infoImage').val(info.data.image);
        $('#infoUsername').val(info.data.username);
        $('#teamID').val(info.data.id);
        $('#enterflag').val(1);
        // 竞价权限,参与竞价(0,1)
        $('#infoPart').val(info.data.part);
        // 平台团队认证
        $('#infoPlat').val(info.data.plat);

      } else if (info.code == 8) {
        // console.log("info.code == 8");
        // 身份过期
        $('#infoStatus').val('');
        $('#infoName').val('');
        $('#infoApprove').val('');
        $('#infoImage').val('');
        $('#infoUsername').val('');
        $('#enterflag').val(8);
        $('#teamID').val('');
      } else if (info.code == 0) {
        // console.log("info.code == 0");
        // 异常操作: 例如身份不符合
        $('#infoStatus').val('');
        $('#infoName').val('');
        $('#infoApprove').val('');
        $('#infoImage').val('');
        $('#infoUsername').val('');
        $('#enterflag').val(0);
        $('#teamID').val('');
      }
    }
  })
}


function quChong(array) {
  var quArray = [];
  var len = array.length;
  for (var i = 0; i < len; i++) {
    for (var j = i + 1; j < len; j++) {
      if (array[i] === array[j]) {
        i++;
        j = i;
      }
    }
    quArray.push(array[i]);
  }
  return quArray;
}

function setCookie(c_name, value, expiredays) {
  var exdate = new Date()
  exdate.setDate(exdate.getDate() + expiredays)
  document.cookie = c_name + "=" + escape(value) +
    ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString())
}

function getCookie(c_name) {
  if (document.cookie.length > 0) {
    c_start = document.cookie.indexOf(c_name + "=")
    if (c_start != -1) {
      c_start = c_start + c_name.length + 1
      c_end = document.cookie.indexOf(";", c_start)
      if (c_end == -1) c_end = document.cookie.length
      return unescape(document.cookie.substring(c_start, c_end))
    }
  }
  return "";
}

function delCookie(c_name) {
  setCookie(c_name, "", -1);
}