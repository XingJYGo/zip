// :"                         ",

var checkNums = 0

// 重大
var impCheckObj = {
  firewall: "               防火墙         ",
  righta: "                  右A柱     ",
  righthrear: "              右后减震器座             ",
  leftc: "               左C柱        ",
  lefta: "                 左A柱        ",
  rightqrear: "            右前减震器座               ",
  rightb: "                右B柱           ",
  leftb: "                 左B柱          ",
  lefthrearspar: "         左后纵梁           ",
  lefthrear: "             左后减震器座             ",
  leftqrear: "             左前减震器座             ",
  leftqrearspar: "         左前纵梁                  ",
  rightqrearspar: "        右前纵梁                   ",
  righthrearspar: "        右后纵梁                   ",
  rightc: "                左C柱          ",
  rightd: "                右D柱          ",
  leftd: "                 左D柱         "

}

// 水淹
var waterCheckObj = {
  taste: "    车内无霉味/臭味      ",
  outlet: "      空调出风口无泥沙        ",
  carpet: "      地毯/地胶无水痕 ",
  engine: "      发动机舱无泥沙沉积        ",
  wire: "    线束无泥沙/更换    ",
  fuse: "    保险丝盒无/泥沙/锈蚀       ",
  seat: "    座椅无水泡拆卸     ",
  trunk: "     后备箱无泥沙/锈蚀        ",
  belts: "     安全带无水泡痕迹       ",
  column: "      转向柱无锈蚀         ",
  cigarette: "         点烟器插座无锈蚀            ",
  bottom: "      座椅底部无水泡锈蚀         "
}

// 火烧
var fireCheckObj = {
  burnt: '                车内无焦糊味         ',
  carbide: '                 防火墙无熏黑/碳化        ',
  engine_room: '          发动机舱线束无熏黑               ',
  engine_black: '               发动机舱无熏黑          ',
  fuse_black: '                    保险丝盒无熏黑/更换      '
}

// 轻微碰撞
var qingCheckObj = {
  left_rear_box: '        左后吸能盒                 ',
  right_rear_box: '            右后吸能盒             ',
  left_front_box: '             左前吸能盒            ',
  right_front_box: '            右前吸能盒             ',
  left_front_lamp: '              左前大灯框架             ',
  right_front_lamp: '    右前大灯框架 ',
  left_rear_lamp: '        左后尾灯框架                 ',
  right_rear_lamp: '        右后尾灯框架                 ',
  left_end_side: '       左底大边                  ',
  right_end_side: '        右底大边                 ',
  front_beam_split: '       前防撞钢梁(可拆)                  ',
  front_beam_notsplit: '        前防撞钢梁(不可拆)                 ',
  left_front_fender: '          左前翼子板内衬/支架               ',
  right_front_fender: '              右前翼子板内衬/支架           ',
  left_rear_fender: '             左后翼子板内衬/支架            ',
  right_rear_fender: '      右后翼子板内衬/支架                   ',
  trunk_floor: '           后备箱底板              ',
  trunk_coaming: '        后备箱围板                 ',
  backlight: '            后窗台板             ',
  cistern_frame: '       水箱框架(可拆)                  ',
  water_chute: '          导水槽               '
}

// 易损耗部件
var yiCheckObj = {
  oil: '         机油                 ',
  fuel_oil: '          助力油                ',
  engine_belt: '        发动机外部皮带                   ',
  antifreeze: '                防冻液          ',
  left_front_brake_pads: '    左前刹车片                      ',
  right_front_brake_pads: '      右前刹车片                     ',
  left_rear_brake_pads: '           左后刹车片                ',
  right_rear_brake_pads: '          右后刹车片                 ',
  left_front_brake_disc: '       左前刹车盘                    ',
  right_front_brake_disc: '      右前刹车盘                     ',
  left_rear_brake_disc: '         左后刹车盘                  ',
  right_rear_brake_disc: '      右后刹车盘                     ',
  left_front_hub: '                左前轮毂           ',
  right_front_hub: '           右前轮毂                ',
  left_rear_hub: '          左后轮毂                 ',
  right_rear_hub: '           右后轮毂                ',
  left_front_tire: '          左前轮胎                 ',
  right_front_tire: '        右前轮胎                   ',
  left_rear_tire: '            左后轮胎               ',
  right_rear_tire: '           右后轮胎                ',
  brake_fluid: '                 制动液          ',
  engine_claw: '              发动机机爪             ',
  battery: '        蓄电池                 '
}

// 4--功能部件
// 动力，传动
var gongDriveObj = {
  engine_line: '         发动机线束                ',
  engine: '发动机',
  coolant_pipes: '    冷却液水管                     ',
  cylinder_block: '     缸盖缸体之间                    ',
  valve_cover: '       气门室盖                  ',
  turbocharger: '         涡轮增压器                ',
  transmission: '    变速箱                      ',
  water_tank: '          水箱                 ',
  cooling_fan: '        冷却风扇 '
}

// 内部配置车内后视镜（内部）
var gongInternalObj = {
  rearview_mirror: '           车内后视镜      ',
  left_front_glass: '          左前门玻璃升降           ',
  right__front_glass: '        右前门玻璃升降             ',
  left_rear_glass: '           左后门玻璃升降                 ',
  right_rear_glass: '          右后门玻璃升降                  ',
  skylight: '               天窗            ',
  conditioning: '           空调                ',
  left_rear_mirror: '       左后视镜                   ',
  right_rear_mirror: '      右后视镜                    ',
  stereo: '                 车内音响扬声器     ',
  after_wiper: '            后雨刮器              ',
  front_wiper: '            前雨刮器              ',
  steering_wheel: '         多功能方向盘               ',
  key: '                    遥控钥匙      ',
  dvd: '                    收音机/CD/DVD    '
}

// 灯光空调 
var gongLightObj = {
  condenser: '              冷凝器          ',
  left_front_lamp: '      左前大灯                  ',
  right_front_lamp: '     右前大灯                   ',
  left_rear_lamp: '       左后尾灯                 ',
  right_rear_lamp: '      右后尾灯                  ',
  left_front_veer: '      左前转向灯/雾灯                   ',
  right_front_veer: '     右前转向灯/雾灯                    ',
  high_low_tube: '        空调高低压管                '
}

// 安全系统
var gongSecurityObj = {
  airbag: '            安全气囊        ',
  main_belt: '         主驾驶安全带                 ',
  vice_belt: '         副驾驶安全带                  ',
  brake: '             制动总泵              ',
  abs: '               ABS泵       '
}
var zhuanObj = {
  part: '转向'
}

// 启动检查
var qiDongObj = {
  engine_start: '     发动机启动                  ',
  smog_check: '       尾气检查                  ',
  gear_detection: '   档位检测                      ',
  static_test: '      转向功能静态检测        '
}


// 随车工具
var suiObj = {
  jack: '         千斤顶             ',
  wrench: '         轮胎扳手        ',
  placard: '        三角警示牌                  ',
  spare: '          备胎          '
}

// 外部检查
var waiCheckObj = {
  left_front_lamp: '            左前大灯               ',
  left_after_door: '             左后车门              ',
  left_after_tail: '            左后尾灯               ',
  right_c: '               右C柱            ',
  right_a: '             右A柱              ',
  trunk_lock: '           后备箱锁              ',
  right_front_door: '       右前车门                    ',
  right_d: '                      右D柱  ',
  right_after_door: '             右后车门            ',
  right_after_lining: '           右后车轮内衬护板               ',
  right_front_triangle_glass: '   右前三角玻璃                       ',
  hood_lock: '                    发动机舱盖锁      ',
  right_after_door_glass: '       右后车门玻璃                   ',
  left_b: '                       左B柱  ',
  right_after_mirror: '           右后视镜               ',
  left_c: '                       左C柱   ',
  left_bottom_side: '             左底大边             ',
  right_bottom_side: '            右底大边             ',
  trunk_lid: '                    后备箱盖     ',
  left_after_fender: '            左后翼子板              ',
  front_bumper: '                 前保险杠     ',
  left_after_mirror: '            左后视镜          ',
  after_wind_glass: '             后挡风玻璃          ',
  engine_room_cover: '            发动机机舱盖             ',
  right_front_lamp: '             右前大灯            ',
  left_after_triangle_glass: '    左后三角玻璃                    ',
  left_front_door_glass: '        左前车门玻璃                ',
  right_front_fender: '           右前翼子板           ',
  right_after_tail: '             右后尾灯             ',
  right_front_swerve: '           右前转向灯/雾灯             ',
  left_d: '                       左D柱   ',
  right_b: '                      右B柱    ',
  left_front_lining: '            左前车轮内衬护板      ',
  left_front_triangle_glass: '    左前三角玻璃                    ',
  right_after_triangle_glass: '   右后三角玻璃                     ',
  left_after_lining: '             左后车轮内衬护板        ',
  roof: '                         车顶',
  after_bumper: '                 后保险杠         ',
  left_front_door: '              左前车门            ',
  left_a: '                       左A柱 ',
  left_front_fender: '            左前翼子板            ',
  left_after_door_glass: '        左后车门玻璃                 ',
  right_after_fender: '           右后翼子板             ',
  front__wind_glass: '            前挡风玻璃            ',
  left_front_swerve: '            左前转向灯/雾灯             ',
  right_front_lining: '           右前车轮内衬护板              ',
  right_front_door_glass: '       右前车门玻璃                 ',
  antenna: '                      天线   ',
  first: '                        前中网 '
}

// 内饰
var neiCheckObj = {
  armrest_box: '              扶手箱         ',
  left_b_panels: '            左B柱内饰板            ',
  rear_seat: '                后排座椅        ',
  roof_panels: '              车顶内饰板           ',
  right_b_panels: '           右B柱内饰板           ',
  desk: '                     仪表台    ',
  rigth_after_door_panels: '  右后门内饰板                        ',
  keys: '                     驻车制动杆/按键    ',
  right_d_panels: '           右D柱内饰板            ',
  left_front_door_panels: '   左前门内饰板                      ',
  left_d_panels: '            左D柱内饰板          ',
  carpet: '                   车内地胶(毯)      ',
  storage: '                  车内储物盒       ',
  main_driving_seat: '        主驾驶座椅                 ',
  left_a_panels: '            左A柱内饰板         ',
  baffle: '                   档把/护罩      ',
  left_c_panels: '            左C柱内饰板         ',
  vice_driving_seat: '        副驾驶座椅                ',
  disc: '                     方向盘     ',
  central: '                  中控台        ',
  left_after_panels: '        左后门内饰板                  ',
  right_a_panels: '           右A柱内饰板              ',
  right_c_panels: '           右C柱内饰板              ',
  right_front_panels: '       右前门内饰板                '
}

// 安全系统
var gongSecurityObj = {
  airbag: '            安全气囊        ',
  main_belt: '         主驾驶安全带                 ',
  vice_belt: '         副驾驶安全带                  ',
  brake: '             制动总泵              ',
  abs: '               ABS泵       '
}

// impCheckObj waterCheckObj  fireCheckObj qingCheckObj  yiCheckObj  gongDriveObj
//  gongInternalObj gongLightObj gongSecurityObj qiDongObj  suiObj  waiCheckObj  neiCheckObj